package br.com.fiap.bo;

import br.com.fiap.beans.PessoaFisica;

public class PessoaFisicaBO {

	public static String CadastrarPessoaFisica(PessoaFisica pf) throws Exception{
		
		if (pf.getNome().length() > 20){
			return "Nome inv�lido";
		}
		 
		if (pf.getEmail().length() > 10) {
            return "Email inv�lido";
        }
		
		if (pf.getRg().length() > 9){
			return "RG inv�lido";
		}
		
		if (pf.getCpf().length() > 11){
			return "CPF inv�lido";
		}
		
		if ((!pf.getSexo().equals("M")) || (!pf.getSexo().equals("F"))){
			return "Sexo inv�lido!";
		}
		
		
		return "";
	}
	
}
