package br.com.fiap.beans;

public class Pessoa {
	
	int codigo;
	String nome;
	String email;
	String senha;
	int tipo;
	int filial;
	
	public Pessoa(){
		super();
	}
	
	public Pessoa(int codigo, String nome, String email, String senha, int tipo, int filial){
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.email = email;
		this.senha = senha;
		this.tipo = tipo;
		this.filial = filial;
		
	}
	
	public int getCodigo() {
		return codigo;
	}
	
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getSenha() {
		return senha;
	}
	
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public int getTipo() {
		return tipo;
	}
	
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
	public int getFilial() {
		return filial;
	}
	
	public void setFilial(int filial) {
		this.filial = filial;
	}
	
	

}
