package br.com.fiap.beans;

public class PessoaJuridica extends Pessoa{

	String cnpj;
	String razaoSocial;
	String ramoAtividade;
	
	public PessoaJuridica(){
		super();
	}
	
	public PessoaJuridica(String cnpj, String razaoSocial, String ramoAtividade){
		super();
		this.cnpj = cnpj;
		this.razaoSocial = razaoSocial;
		this.ramoAtividade = ramoAtividade;
	}
	
	public String getCnpj() {
		return cnpj;
	}
	
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	
	public String getRazaoSocial() {
		return razaoSocial;
	}
	
	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}
	
	public String getRamoAtividade() {
		return ramoAtividade;
	}
	
	public void setRamoAtividade(String ramoAtividade) {
		this.ramoAtividade = ramoAtividade;
	}
	
	
	
}
