package br.com.fiap.beans;

import java.util.Calendar;

public class PessoaFisica extends Pessoa{

	String rg;
	String cpf;
	Calendar nascimento;
	String sexo;
	
	public PessoaFisica(){
		super();
	}
	
	public PessoaFisica(String rg, String cpf, Calendar nascimento, String sexo){
		super();
		this.rg = rg;
		this.cpf = cpf;
		this.nascimento = nascimento;
		this.sexo = sexo;
	}
	
	public String getRg() {
		return rg;
	}
	
	public void setRg(String rg) {
		this.rg = rg;
	}
	
	public String getCpf() {
		return cpf;
	}
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	public Calendar getNascimento() {
		return nascimento;
	}
	
	public void setNascimento(Calendar nascimento) {
		this.nascimento = nascimento;
	}
	
	public String getSexo() {
		return sexo;
	}
	
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	
	
}
