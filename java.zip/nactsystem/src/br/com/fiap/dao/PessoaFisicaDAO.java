package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import br.com.fiap.beans.PessoaFisica;
import br.com.fiap.conexao.ConexaoFactory;

public class PessoaFisicaDAO {

	private Connection conn;
	
	public PessoaFisicaDAO () throws Exception {
		conn = new ConexaoFactory().conectar();
	}
	
	public String fechar() throws Exception {
		conn.close();
		return "Conex�o fechada com sucesso.";
	}
	
	public String CadastraPessoaFisica(PessoaFisica pf) throws Exception{
		
		PreparedStatement pstmt = null; 
		pstmt = conn.prepareStatement("INSERT INTO T_GCS_PESSOA "
				+ "(cd_pessoa, NM_CLIENTE, QT_ESTRELAS) VALUES (?, ?, ?)");
		pstmt.setString(1, pf.getNome());
		pstmt.setString(2, pf.getEmail());
		pstmt.setString(3, pf.getCpf());
		pstmt.execute();
		
		return "";
	}
	
}
