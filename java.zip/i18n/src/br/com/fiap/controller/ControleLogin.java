package br.com.fiap.controller;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.jstl.core.Config;

/**
 * Servlet implementation class ControleLogin
 */
@WebServlet("/agente")
public class ControleLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControleLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/* 
		 * imprime em html
		 
		PrintWriter pw = response.getWriter();
		
		pw.print("<p>SEU RESPONSE FOI GERADO</p>");
		pw.print("<p><a href='index.jsp'>INDEX</a></p>");
		
		pw.flush();
		pw.close();
		*/
		
		// RECUPERANDO O PARAMETRO DO REQUEST COM A LINGUA DESEJADA
		String language = request.getParameter("lingua");
		
		// CRIANDO O OBJETO LOCALE QUE CONTROLA QUAL LINGUA SER� CARREGADA NO SISTEMA
		Locale locale = new Locale(language);
		
		// CONFIGURAR O LOCALE NA SESS�O DO USUARIO
		HttpSession sessao  = request.getSession();
		
		Config.set(sessao, Config.FMT_LOCALE, locale);
		Config.set(sessao, Config.FMT_FALLBACK_LOCALE, locale);
		
		// CONFIGURANDO O TIMEOUT DA SESS�O
		sessao.setMaxInactiveInterval(10);
		
		// CRIANDO UM ATRIBUTO NO REQUEST
		request.setAttribute("lingua", language);
		
		// CRIANDO O ATRIBUTO NA SESS�O DO USUARIO
		sessao.setAttribute("lingua", language);
		
		//Criando o dispacther para integrar o request com a p�gina que receber� o atributo
		RequestDispatcher fw = request.getRequestDispatcher("index.jsp");
		
		//Realizando o redirecionamento e encaminhando o quest com o atributo e o response.
		fw.forward(request, response);
		
		
		
	}

}
