package br.com.fiap.beans;

import java.util.List;

public class Fornecedor {

	private String razaoSocial;
	private String cnpj;
	private String email;
	private int cd_fornecedor;

	private List<Telefone> fones;

	public Fornecedor(String razaoSocial, String cnpj, String email, int cd_fornecedor){
		super();
		setRazaoSocial(razaoSocial);
		setCnpj(cnpj);
		setEmail(email);
		setCd_fornecedor(cd_fornecedor);
	}
	
	public Fornecedor(){
		super();
	}
	
	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getCd_fornecedor() {
		return cd_fornecedor;
	}

	public void setCd_fornecedor(int cd_fornecedor) {
		this.cd_fornecedor = cd_fornecedor;
	}

	public List<Telefone> getFones() {
		return fones;
	}

	public void setFones(List<Telefone> fones) {
		this.fones = fones;
	}
	
	
}
