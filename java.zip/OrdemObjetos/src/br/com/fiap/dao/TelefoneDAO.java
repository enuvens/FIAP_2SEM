package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Telefone;
import br.com.fiap.conexao.ConexaoFactory;

public class TelefoneDAO {

	private Connection conn;
	
	public TelefoneDAO() throws Exception {
		conn = new ConexaoFactory().conectar();
	}
	
	public String fechar() throws Exception {
		conn.close();
		return "Conex�o fechada com sucesso.";
	}
	
	public String gravar(Telefone telefone, int cliente) throws Exception {
		PreparedStatement pstmt = null; 
		pstmt = conn.prepareStatement("INSERT INTO TB_DDD_TELEFONE "
				+ "(NR_DDD, NR_NUMERO, NM_OPERADORA, NR_CLIENTE) "
				+ "VALUES (?, ?, ?, ?)");
		pstmt.setInt(1, telefone.getDdd());
		pstmt.setString(2, telefone.getNumero());
		pstmt.setString(3, telefone.getOperadora());
		pstmt.setInt(4, cliente);
		pstmt.execute();
		pstmt.close();
		return "Cadastrado com sucesso.";
	}
	
	public List<Telefone> consultarPorNumeroCliente(int numero) throws Exception{
		
		PreparedStatement pstmt = null;
		pstmt = conn.prepareStatement("SELECT * FROM TB_DDD_TELEFONE WHERE NR_CLIENTE = ?");
		pstmt.setInt(1, numero);
		
		ResultSet rs = pstmt.executeQuery();
		
		List<Telefone> lista = new ArrayList<>();
		while(rs.next()){
			lista.add(new Telefone(
					rs.getInt("NR_DDD"),
					rs.getString("NR_NUMERO"),
					rs.getString("NM_OPERADORA"),
					rs.getInt("NR_CLIENTE")
					));
		}
		
		rs.close();
		pstmt.close();
		return lista;
	}
	
	public List<Telefone> consultarPorOperadora(String operadora) throws Exception{
		
		PreparedStatement pstmt = null;
		pstmt = conn.prepareStatement("SELECT * FROM TB_DDD_TELEFONE WHERE NM_OPERADORA = ?");
		pstmt.setString(1, operadora);
		
		ResultSet rs = pstmt.executeQuery();
		
		List<Telefone> lista = new ArrayList<>();
		while(rs.next()){
			lista.add(new Telefone(
					rs.getInt("NR_DDD"),
					rs.getString("NR_TELEFONE"),
					rs.getString("NM_OPERADORA"),
					rs.getInt("NR_CLIENTE")
					));
		}
		
		rs.close();
		pstmt.close();
		return lista;
	}
	
	public List<Telefone> alterarPorNumeroTelefone(String fone) throws Exception{
		
		PreparedStatement pstmt = null;
		pstmt = conn.prepareStatement("SELECT * FROM TB_DDD_TELEFONE WHERE NR_TELEFONE = ?");
		pstmt.setString(1, fone);
		
		ResultSet rs = pstmt.executeQuery();
		
		List<Telefone> lista = new ArrayList<>();
		while(rs.next()){
			lista.add(new Telefone(
					rs.getInt("NR_DDD"),
					rs.getString("NR_TELEFONE"),
					rs.getString("NM_OPERADORA"),
					rs.getInt("NR_CLIENTE")
					));
		}
		
		rs.close();
		pstmt.close();
		return lista;
	}
	
	public int excluirPorNumeroCliente(int numero) throws Exception {
		PreparedStatement pstmt = null; 
		pstmt = conn.prepareStatement("DELETE FROM TB_DDD_TELEFONE WHERE NR_CLIENTE = ?");
		pstmt.setInt(1, numero);
		int r = pstmt.executeUpdate();
		pstmt.close();
		return r;
	}
	
	public int excluirPorNumeroTelefone(int numero) throws Exception {
		PreparedStatement pstmt = null; 
		pstmt = conn.prepareStatement("DELETE FROM TB_DDD_TELEFONE WHERE NR_TELEFONE = ?");
		pstmt.setInt(1, numero);
		int r = pstmt.executeUpdate();
		pstmt.close();
		return r;
	}
	
}
