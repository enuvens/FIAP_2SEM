package br.com.fiap.testes;

import br.com.fiap.dao.ClienteDAO;

public class TesteAlterarCliente {

	public static void main(String[] args) {
		ClienteDAO dao = null;
		int n = 2;
		try {
			dao = new ClienteDAO();
			System.out.println(dao.elevarNivel(n));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				System.out.println(dao.fechar());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
