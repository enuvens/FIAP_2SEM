package br.com.fiap.testes;

import java.util.List;

import br.com.fiap.beans.Cliente;
import br.com.fiap.beans.Telefone;
import br.com.fiap.dao.ClienteDAO;

public class TesteClienteLista {

	public static void main(String[] args) {
		ClienteDAO dao = null;
		try {
			dao = new ClienteDAO();
			List<Cliente> lista = dao.getListarNivel(4);
			for(Cliente c : lista) {
				System.out.println(c.getNome());
				System.out.println(c.getNumero());
				System.out.println();
				
				for (Telefone t : c.getFones()){
					System.out.println(t.getDdd());
					System.out.println(t.getNumero());
					System.out.println(t.getOperadora());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dao.fechar();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

}
