package br.com.fiap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/exemplo")
public class ServletExemplo extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ServletExemplo() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Recebendo o par�metro da p�gina index do link LINK 
		String parametro = request.getParameter("msg");
		
		//System.out.println("Valor do par�metro: "+ parametro);
		
		PrintWriter pw = response.getWriter();
		
		pw.print("<h1>"+ parametro +"</h1>");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
