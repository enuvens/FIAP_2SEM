package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import br.com.fia.beans.Produto;
import br.com.fia.conexao.ConexaoFactory;

public class ProdutoDAO {

	private Connection con;
	
	public ProdutoDAO() throws Exception {
		con = new ConexaoFactory().conectar();
	}
	
	public String fechar() throws Exception{
		con.close();
		return "Conex�o fechada";
	}
	
	public String inserir(Produto pro) throws Exception{
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("INSERT INTO TB_DDD_PRODUTO "
				+ "(CD_PRODUTO, DS_PRODUTO, NM_CATEGORIA) VALUES (?, ?, ?)");
		estrutura.setInt(1, pro.getNumero());
		estrutura.setString(2, pro.getNome());
		estrutura.setString(3, pro.getCategoria());
		
		estrutura.execute();
		estrutura.close();
		
		return "Produto cadastrado com sucesso";
	}
	
}
