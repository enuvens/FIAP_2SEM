package br.com.fia.beans;

public class Cliente {

	private int numero;
	private String nome;
	private int qtEstrelas;
	
	public Cliente(String nome, int numero, int qtEstrelas){
		super();
		setNome(nome);
		setNumero(numero);
		setQtEstrelas(qtEstrelas);
	}

	public Cliente(){
		super();
	}
	
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome.toUpperCase();
	}
	public int getQtEstrelas() {
		return qtEstrelas;
	}
	public void setQtEstrelas(int qtEstrelas) {
		this.qtEstrelas = qtEstrelas;
	}
	
	
}
