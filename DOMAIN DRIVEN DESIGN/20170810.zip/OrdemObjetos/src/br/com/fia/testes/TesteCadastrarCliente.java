package br.com.fia.testes;

import javax.swing.JOptionPane;

import br.com.fia.beans.Cliente;
import br.com.fiap.dao.ClienteDAO;

public class TesteCadastrarCliente {

	public static void main(String[] args) {
		
		Cliente obj = new Cliente();
		obj.setNome(JOptionPane.showInputDialog("Digite o nome"));
		obj.setNumero(Integer.parseInt(JOptionPane.showInputDialog("Digite o numero")));
		obj.setQtEstrelas(Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de estrelas")));
		
		ClienteDAO dao = null;
		
		try{
			dao = new ClienteDAO();
			System.out.println(dao.inserir(obj));
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try{
				System.out.println(dao.fechar());
			} catch (Exception e){
				e.printStackTrace();
			}
		}
	}
}
