package br.com.fia.testes;

import javax.swing.JOptionPane;

import br.com.fia.beans.Cliente;
import br.com.fiap.dao.ClienteDAO;

public class TesteConsultarCliente {

	public static void main(String[] args) {
		
		int numero = Integer.parseInt(JOptionPane.showInputDialog("Digite o numero do cliente"));
		
		ClienteDAO dao = null;
		
		try{
			dao = new ClienteDAO();
			Cliente obj = dao.consultar(numero);
			
			System.out.println(obj.getNumero() +" - "+ obj.getNome() +" - "+ obj.getQtEstrelas());
		
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try{
				System.out.println(dao.fechar());
			} catch (Exception e){
				e.printStackTrace();
			}
		}
	}
}
