PACKAGE		== DESCRI��O
----------------------------------------------------------
CONEX�O 	=> 
BO 			=> Regras de Negocio
DAO			=> CRUD (Create | Request | Update | Delete)
EXCESS�ES	=> 
BEANS 		=> Modelo
TESTES		=> 
