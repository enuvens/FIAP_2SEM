import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Conexao_v5 {

	public static void main(String[] args) {
		Connection conectar = null;
		PreparedStatement estrutura = null;
		ResultSet resultado = null;

		try{
			conectar = DriverManager.getConnection("jdbc:oracle:thin:@192.168.60.15:1521:ORCL", "RM78582", "130483");
			
			String strNome = JOptionPane.showInputDialog("Digite o login:");
			int intSenha = Integer.parseInt(JOptionPane.showInputDialog("Digite a senha"));
			
			estrutura = conectar.prepareStatement("SELECT * FROM TB_DDD_CLIENTE WHERE NM_CLIENTE = ? AND NR_CLIENTE = ?");
			estrutura.setInt(1, intSenha);
			estrutura.setString(2, strNome);
			
			resultado = estrutura.executeQuery();
			
			if(resultado.next()){
				System.out.println("Logado");
			} else {
				System.out.println("Bloqueado");
			}
		} catch (SQLException e){
			e.printStackTrace();
		} finally {
			try{
				resultado.close();
				estrutura.close();
				conectar.close();
			} catch(SQLException e){
				e.printStackTrace();
			}
		}

	}

}
