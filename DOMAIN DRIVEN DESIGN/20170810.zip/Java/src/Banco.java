import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Banco {

	public static void main(String[] args) throws SQLException {

		Connection conexao = null;
		
		String url = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
		String user = "RM78582";
		String password = "130483";
		
		conexao = DriverManager.getConnection(url, user, password);
		
		System.out.println("Abriu conex�o");
		conexao.close();

		
		
	}

}
