package br.com.fiap.testes;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.bo.ClienteBO;
import br.com.fiap.excecoes.Excecao;

public class TesteConsultaCliente2 {

	public static void main(String[] args) {

		Cliente obj = new Cliente();
		
		obj.setNome(JOptionPane.showInputDialog("Digite o nome"));
		
		obj.setNumero(Integer.parseInt(JOptionPane.showInputDialog("Digite um n�mero")));
		
		obj.setQtdeEstrelas(Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de estrelas")));

		try {
			System.out.println(ClienteBO.novoCliente(obj));
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println(Excecao.tratarExcecao(e));
		}
		
	}

}
