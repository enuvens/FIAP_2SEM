package br.com.fiap.testes;

import br.com.fiap.beans.Cliente;
import br.com.fiap.dao.ClienteDAO;

public class TesteCadastrarCliente {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cliente cliente = new Cliente("Raphael Teste", 5, 1);
		ClienteDAO dao = null;
		try {
			dao = new ClienteDAO();
			System.out.println(dao.gravar(cliente));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				System.out.println(dao.fechar());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		

		
	}

}
