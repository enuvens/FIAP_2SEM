package br.com.fiap.testes;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.beans.Telefone;
import br.com.fiap.dao.ClienteDAO;

public class TesteConsultaCliente3 {

	public static void main(String[] args) {

		Cliente obj = new Cliente();
		ClienteDAO dao = null;
		
		obj.setNome(JOptionPane.showInputDialog("Digite o nome"));
		
		obj.setNumero(Integer.parseInt(JOptionPane.showInputDialog("Digite um n�mero")));
		
		obj.setQtdeEstrelas(Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de estrelas")));

		Telefone fone = new Telefone();
		List<Telefone> fones = new ArrayList<Telefone>();
		
		do {
			fone = new Telefone();
			fone.setDdd(Integer.parseInt(JOptionPane.showInputDialog("DDD")));
			fone.setNumero(JOptionPane.showInputDialog("Numero"));
			fone.setOperadora(JOptionPane.showInputDialog("Operadora"));
			fones.add(fone);
			
		} while (JOptionPane.showConfirmDialog(null,  "Continuar?", "Add Telefone",
				JOptionPane.YES_NO_OPTION,
				JOptionPane.QUESTION_MESSAGE) == 0);
		
		obj.setTelefone(fones);
		
		try {
			dao = new ClienteDAO();
			System.out.println(dao.gravar(obj));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
