package br.com.fiap.bo;

import java.util.List;

import br.com.fiap.beans.Cliente;
import br.com.fiap.dao.ClienteDAO;

public class ClienteBO {
	public static String novoCliente (Cliente cliente) throws Exception {
		
		if (cliente.getQtdeEstrelas() < 1 || cliente.getQtdeEstrelas() > 5) {
			return "Qtde Estrelas inv�lida.";
		}
		
		if (cliente.getNome().length() > 50){
			return "Nome inv�lido";
		}
		
		if (cliente.getNumero()<0){
			return "Numero inv�lido";
		}
		
		ClienteDAO dao = new ClienteDAO();
		String msg = dao.gravar(cliente);
		dao.fechar();
		
		return msg;
	}
	
	public static Cliente consultarPorCodigo(int n) throws Exception{
		
		ClienteDAO dao = new ClienteDAO();
		Cliente c = dao.getCliente(n);
		
		dao.fechar();
		
		return c;
	}
	
	public static int apagarPorNome(String nome) throws Exception{
		
		ClienteDAO dao = new ClienteDAO();
		int msg = dao.excluirNome(nome);
		
		dao.fechar();
		
		return msg;
	}
	
	public static String aumentarEstrela(int n) throws Exception{
		
		ClienteDAO dao = new ClienteDAO();
		Cliente obj = dao.getCliente(n);
		
		if (obj.getQtdeEstrelas() >= 5 ){
			return "Limite alca�ado";
		} 
		
		String msg = dao.elevarNivel(n);
		dao.fechar();
		return msg;
	}
	
	public static List<Cliente> consultaPorNivel(int qe) throws Exception{
		
		ClienteDAO dao = new ClienteDAO();
		
		List<Cliente> x = dao.getListarNivel(qe);
		dao.fechar();
		
		return x;
		
	}
	
}