package br.com.fiap.beans;

public class Telefone {

	private int ddd;
	private String numero;
	private String operadora;
	private int nr_cliente;

	public Telefone(int ddd, String numero, String operadora, int nr_cliente){
		super();
		setDdd(ddd);
		setNumero(numero);
		setOperadora(operadora);
		setNr_cliente(nr_cliente);
	}
	
	public Telefone(){
		super();
	}
	
	public int getNr_cliente() {
		return nr_cliente;
	}

	public void setNr_cliente(int nr_cliente) {
		this.nr_cliente = nr_cliente;
	}

	public int getDdd() {
		return ddd;
	}
	
	public void setDdd(int ddd) {
		this.ddd = ddd;
	}
	
	public String getNumero() {
		return numero;
	}
	
	public void setNumero(String numero) {
		this.numero = numero;
	}
	
	public String getOperadora() {
		return operadora;
	}
	
	public void setOperadora(String operadora) {
		this.operadora = operadora;
	}
	
}
