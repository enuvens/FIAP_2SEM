package br.com.fiap.beans;

import java.util.List;

public class Cliente {
	private String nome;
	private int numero;
	private int qtdeEstrelas;

	private List<Telefone> fones;
	
	public List<Telefone> getFones() {
		return fones;
	}

	public void setTelefone(List<Telefone> telefone) {
		this.fones = telefone;
	}

	public Cliente() {
		super();
	};
	
	public Cliente(String nome, int numero, int qtdeEstrelas) {
		super();
		setNome(nome);
		setNumero(numero);
		setQtdeEstrelas(qtdeEstrelas);
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public int getQtdeEstrelas() {
		return qtdeEstrelas;
	}
	public void setQtdeEstrelas(int qtdeEstrelas) {
		this.qtdeEstrelas = qtdeEstrelas;
	}
}
