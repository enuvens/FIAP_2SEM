package br.com.fiap.testes;

import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Produto;
import br.com.fiap.dao.ProdutoDAO;

public class TesteProduto {

	public static void main(String[] args) {
		ProdutoDAO dao = null;
		Produto produto = null;
		try {
			dao = new ProdutoDAO();
			do {
				char op = JOptionPane.showInputDialog("Digite:\n"
						+ "<C> para Cadastrar\n"
						+ "<N> para Consultar\n"
						+ "<A> para Aumentar\n"
						+ "<L> para Listar\n"
						+ "<E> para Excluir").toUpperCase().charAt(0);
				if (op == 'C') {
					//Cadastrar
					produto = new Produto(1, "Teclado", "Inform�tica", 100.00);
					System.out.println(dao.gravar(produto));
				} else if (op == 'N') {
					//Consultar
					produto = dao.getProduto(1);
					System.out.println(produto.getNome());
					System.out.println(produto.getCategoria());
					System.out.println(produto.getValor());
				} else if (op == 'A'){
					//Aumentar
					System.out.println(dao.aumentar(50) + " linha(s) alterada(s)");
				} else if (op == 'E') {
					//Excluir
					System.out.println(dao.excluirPorCodigo(1) + " linha(s) excluida(s)");
				} else if (op == 'L') {
					dao = new ProdutoDAO();
					List<Produto> lista = dao.listarPorCategoria("Inform�tica");
					for(Produto p : lista) {
						System.out.println(p.getNome());
						System.out.println();
					}
				} else {
					System.out.println("Op��o inv�lida.");
				}
			} while (JOptionPane.showConfirmDialog(null, "Continuar?", "DAOPRODUTO", 
					JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE) == 0);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dao.fechar();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
			
	}

}
