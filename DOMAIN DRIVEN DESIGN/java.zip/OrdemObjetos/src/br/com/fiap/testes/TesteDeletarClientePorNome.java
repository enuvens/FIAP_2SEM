package br.com.fiap.testes;

import br.com.fiap.dao.ClienteDAO;

public class TesteDeletarClientePorNome {

	public static void main(String[] args) {
		ClienteDAO dao = null;
		String n = "Eduardo";
		try {
			dao = new ClienteDAO();
			System.out.println(dao.excluirNome(n) + " cliente(s) foi(ram) apagado(s)!");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				System.out.println(dao.fechar());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
