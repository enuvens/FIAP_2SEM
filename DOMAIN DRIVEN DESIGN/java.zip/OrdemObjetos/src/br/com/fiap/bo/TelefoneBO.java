package br.com.fiap.bo;

import java.util.List;

import br.com.fiap.beans.Telefone;
import br.com.fiap.dao.TelefoneDAO;

public class TelefoneBO {

	public static String novoTelefone(Telefone fone, int numeroCliente) throws Exception{
		
		if (fone.getDdd() < 1 && fone.getDdd() > 1000){
			return "DDD inv�lido";
		}
		
		if (fone.getNumero().length() < 8 && fone.getNumero().length() > 10){
			return "Telefone inv�lido";
		}
		
		if (fone.getOperadora().length() < 1){
			return "Operadora inv�lida";
		}
		
		TelefoneDAO dao = new TelefoneDAO();
		
		String msg = dao.gravar(fone, numeroCliente);
		
		dao.fechar();
		return msg;
		
	}
	
	public static List<Telefone> localizarOperadora(String operadora) throws Exception{
		
		TelefoneDAO dao = new TelefoneDAO();
		
		List<Telefone> x = dao.consultarPorOperadora(operadora);
		
		dao.fechar();
		return x;
	}
	
	public static int apagaPorTelefone(int numero) throws Exception{
		
		TelefoneDAO dao = new TelefoneDAO();
		
		int x = dao.excluirPorNumeroTelefone(numero);
		
		dao.fechar();
		return x;
	}
	
	public static List<Telefone> alterarOperadora(String fone) throws Exception{
		
		TelefoneDAO dao = new TelefoneDAO();
		
		dao.fechar();
		
		return dao.alterarPorNumeroTelefone(fone);
		
	}
}
