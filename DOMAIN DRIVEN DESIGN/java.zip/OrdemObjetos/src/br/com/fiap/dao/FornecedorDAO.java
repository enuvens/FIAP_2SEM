package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.conexao.ConexaoFactory;

public class FornecedorDAO {

	private Connection conn;
	
	public FornecedorDAO () throws Exception {
		conn = new ConexaoFactory().conectar();
	}
	public String fechar() throws Exception {
		conn.close();
		return "Conex�o fechada com sucesso.";
	}
	
}
