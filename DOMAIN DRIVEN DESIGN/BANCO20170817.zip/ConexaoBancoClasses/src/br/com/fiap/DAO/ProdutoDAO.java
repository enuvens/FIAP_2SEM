package br.com.fiap.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Cliente;
import br.com.fiap.beans.Produto;
import br.com.fiap.conexao.ConexaoFactory;

public class ProdutoDAO {

	private Connection con;
	
	public ProdutoDAO() throws Exception {
		con = new ConexaoFactory().conectar();
	}
	
	public String fechar() throws Exception{
		con.close();
		return "Conex�o fechada";
	}
	
	public String inserir(Produto pro) throws Exception{
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("INSERT INTO TB_DDD_PRODUTO "
				+ "(CD_PRODUTO, DS_PRODUTO, NM_CATEGORIA, VL_PRECO) VALUES (?, ?, ?, ?)");
		estrutura.setInt(1, pro.getNumero());
		estrutura.setString(2, pro.getNome());
		estrutura.setString(3, pro.getCategoria());
		estrutura.setDouble(4, pro.getPreco());
		
		estrutura.execute();
		estrutura.close();
		
		return "Produto cadastrado com sucesso";
	}
	
	public String alterar(Produto pro) throws Exception{
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("UPDATE TB_DDD_PRODUTO SET DS_PRODUTO = ?, NM_CATEGORIA = ?, "
				+ "VL_PRECO = ? WHERE CD_PRODUTO = ?");
		estrutura.setString(1, pro.getNome());
		estrutura.setString(2, pro.getCategoria());
		estrutura.setDouble(3, pro.getPreco());
		estrutura.setInt(3, pro.getNumero());
		
		estrutura.execute();
		estrutura.close();
		
		return "Alterado com sucesso!";
		
	}

	public String excluir(int numero) throws Exception{
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("DELETE TB_DDD_PRODUTO WHERE CD_PRODUTO = ?");
		estrutura.setInt(1, numero);
		
		estrutura.execute();
		estrutura.close();
		
		return "Excluido com sucesso!";
		
	}
	
	public Produto consultar(int numero) throws Exception{
		
		Produto pro = new Produto();
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("SELECT * FROM TB_DDD_PRODUTO WHERE CD_PRODUTO = ?");
		estrutura.setInt(1, numero);
		
		ResultSet resultado = estrutura.executeQuery();
		
		if (resultado.next()){
			pro.setNumero(resultado.getInt("CD_PRODUTO"));
			pro.setNome(resultado.getString("DS_PRODUTO"));
			pro.setCategoria(resultado.getString("NM_CATEGORIA"));
			pro.setPreco(resultado.getInt("VL_PRECO"));
		}
		
		resultado.close();
		estrutura.close();
		
		return pro;
	}
	
	public String aumentar(int porcentagem) throws Exception{
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("UPDATE TB_DDD_PRODUTO SET VL_PRECO = (VL_PRECO * ?)");
		estrutura.setInt(1, porcentagem);
		
		estrutura.execute();
		estrutura.close();
		
		return "Valores alterados com sucesso!";
	}

	public List<Produto> getListarCategoria (String categoria) throws Exception{
		
		List<Produto> lista = new ArrayList<>();
		
		Produto obj = new Produto();
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("SELECT * FROM TB_DDD_PRODUTO WHERE NM_CATEGORIA = ?");
		estrutura.setString(1, categoria);
		
		ResultSet resultado = estrutura.executeQuery();
		
		while (resultado.next()){
			//N�o esquecer
			obj = new Produto();
			
			obj.setNumero(resultado.getInt("CD_PRODUTO"));
			obj.setNome(resultado.getString("DS_PRODUTO"));
			obj.setPreco(resultado.getDouble("VL_PRECO"));
			
			lista.add(obj);
		}
		
		resultado.close();
		estrutura.close();
		
		return lista;
		
	}
	
}
