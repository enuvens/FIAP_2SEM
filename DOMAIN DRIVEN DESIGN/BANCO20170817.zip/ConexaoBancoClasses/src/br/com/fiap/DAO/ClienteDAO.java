package br.com.fiap.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Cliente;
import br.com.fiap.conexao.ConexaoFactory; 

public class ClienteDAO {

	private Connection con;
	
	public ClienteDAO() throws Exception {
		con = new ConexaoFactory().conectar();
	}
	
	public String fechar() throws Exception{
		con.close();
		return "Conex�o fechada";
	}
	
	public String inserir(Cliente cli) throws Exception{
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("INSERT INTO T_DDD_CLIENTEA"
				+ "(NR_CLIENTE, NM_CLIENTE, QT_ESTRELAS) VALUES (?, ?, ?)");
		estrutura.setInt(1, cli.getNumero());
		estrutura.setString(2, cli.getNome());
		estrutura.setInt(3, cli.getQtEstrelas());
		
		estrutura.execute();
		estrutura.close();
		
		return "Cadastrado com sucesso!";
		
	}
	
	public String alterar(Cliente cli) throws Exception{
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("UPDATE TB_DDD_CLIENTE  SET NM_CLIENTE = ?, QT_ESTRELAS = ?"
				+ " WHERE NR_CLIENTE = ?");
		estrutura.setString(1, cli.getNome());
		estrutura.setInt(2, cli.getQtEstrelas());
		estrutura.setInt(3, cli.getNumero());
		
		estrutura.execute();
		estrutura.close();
		
		return "Alterado com sucesso!";
		
	}
	
	public String excluir(Cliente cli) throws Exception{
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("DELETE TB_DDD_CLIENTE WHERE NR_CLIENTE = ?");
		estrutura.setInt(1, cli.getNumero());
		
		estrutura.execute();
		estrutura.close();
		
		return "Excluido com sucesso!";
	}
	
	public Cliente consultar(int numero) throws Exception{
		
		Cliente cli = new Cliente();
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("SELECT * FROM TB_DDD_CLIENTE WHERE NR_CLIENTE = ?");
		estrutura.setInt(1, numero);
		
		ResultSet resultado = estrutura.executeQuery();
		
		if (resultado.next()){
			cli.setNome(resultado.getString("NM_CLIENTE"));
			cli.setNumero(resultado.getInt("NR_CLIENTE"));
			cli.setQtEstrelas(resultado.getInt("QT_ESTRELAS"));
		}
		
		resultado.close();
		estrutura.close();
		
		return cli;
		
	}
		
	public int excluirNome(String pNome) throws Exception{
		
		PreparedStatement estrutura = con.prepareStatement("DELETE FROM  TB_DDD_CLIENTE WHERE NM_CLIENTE LIKE ?");
		estrutura.setString(1, "%"+pNome+"%");
		
		int x =	estrutura.executeUpdate();
		estrutura.close();
		
		return x;
	}
	
	
	public List<Cliente> getListarNivel (int estrelas) throws Exception{
		
		List<Cliente> lista = new ArrayList<>();
		
		Cliente objCliente = new Cliente();
		
		PreparedStatement estrutura = null;
		
		estrutura = con.prepareStatement("SELECT * FROM TB_DDD_CLIENTE WHERE QT_ESTRELAS = ?");
		estrutura.setInt(1, estrelas);
		
		ResultSet resultado = estrutura.executeQuery();
		
		while (resultado.next()){
			//N�o esquecer
			objCliente = new Cliente();
			
			objCliente.setNome(resultado.getString("NM_CLIENTE"));
			objCliente.setNumero(resultado.getInt("NR_CLIENTE"));
			objCliente.setQtEstrelas(resultado.getInt("QT_ESTRELAS"));
			
			lista.add(objCliente);
		}
		
		resultado.close();
		estrutura.close();
		
		return lista;
		
	}
	
}
