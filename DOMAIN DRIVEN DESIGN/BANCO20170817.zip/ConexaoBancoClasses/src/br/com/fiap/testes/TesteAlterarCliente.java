package br.com.fiap.testes;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.DAO.ClienteDAO;

public class TesteAlterarCliente {

	public static void main(String[] args) {
		
		Cliente obj = new Cliente();
		obj.setNumero(Integer.parseInt(JOptionPane.showInputDialog("Digite o numero")));
		obj.setNome(JOptionPane.showInputDialog("Digite o nome"));
		obj.setQtEstrelas(Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de estrelas")));
		
		ClienteDAO dao = null;
		
		try{
			dao = new ClienteDAO();
			System.out.println(dao.alterar(obj));
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try{
				System.out.println(dao.fechar());
			} catch (Exception e){
				e.printStackTrace();
			}
		}
	}
}
