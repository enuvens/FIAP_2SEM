
package br.com.fiap.testes;

import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.DAO.ProdutoDAO;
import br.com.fiap.beans.Produto;

public class TesteProdutoExcluirCodigo {

	public static void main(String[] args) {

		ProdutoDAO dao = null;
		
		try {
			
			dao = new ProdutoDAO();

			do{
				
				char op = JOptionPane.showInputDialog(
						"Digite:\n<C> para cadastrar\n"
						+ "<N> para consultar\n"
						+ "<A> para aumentar\n"
						+ "<B> para buscar por categoria\n"
						+ "<E> para excluir").toUpperCase().charAt(0);
				
				if (op == 'C'){
					Produto pro = new Produto();
					pro.setNome(JOptionPane.showInputDialog("Descri�ao"));
					pro.setCategoria(JOptionPane.showInputDialog("Categoria"));
					pro.setPreco(Double.parseDouble(JOptionPane.showInputDialog("Valor")));
					pro.setNumero(Integer.parseInt(JOptionPane.showInputDialog("C�digo")));

					System.out.println(dao.inserir(pro));
				
				} else if (op == 'N'){
					
					int cod = Integer.parseInt(JOptionPane.showInputDialog("C�digo"));
					
					Produto pro = dao.consultar(cod);
					
					System.out.println("C�digo: "+ pro.getNumero());
					System.out.println("Descri��o: "+ pro.getNome());
					System.out.println("Pre�o: "+ pro.getPreco());
					System.out.println("Categoria: "+ pro.getCategoria());

				} else if (op == 'A'){
					int cod = Integer.parseInt(JOptionPane.showInputDialog("Porcentagem"));
					
					System.out.println(dao.aumentar(cod));
					
				} else if (op == 'E'){
					int cod = Integer.parseInt(JOptionPane.showInputDialog("C�digo"));
					
					System.out.println(dao.excluir(cod));
				} else if (op == 'B'){

					List<Produto> lista = dao.getListarCategoria(JOptionPane.showInputDialog("Categoria"));
					
					for (Produto p : lista){
						System.out.println(p.getNumero() +" - "+ p.getNome() +" - "+ p.getPreco());
						System.out.println();
					}
					
				} else {
					System.out.println("Op��o inv�lida!");
				}
				
			} while (JOptionPane.showConfirmDialog
					(null, "Continuar?", "DAOPRODUTO",
					JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE) == 0);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dao.fechar();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
}

