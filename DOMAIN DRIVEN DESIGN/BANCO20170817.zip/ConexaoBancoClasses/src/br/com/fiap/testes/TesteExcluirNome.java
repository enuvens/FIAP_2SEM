package br.com.fiap.testes;

import javax.swing.JOptionPane;

import br.com.fiap.DAO.ClienteDAO;
import br.com.fiap.beans.Cliente;

public class TesteExcluirNome {

	public static void main(String[] args) {
		// 1� try catch exception
		
		//2 instanciar o DAO FORA
		ClienteDAO dao = null;
		
		try {
			
			String nome = JOptionPane.showInputDialog("NOME").toUpperCase();
			
			dao = new ClienteDAO();
			//Instancia o DAO DENTRO

			dao.excluirNome(nome);
			//Chamar o Metodo
			
			System.out.println(nome +" clientes(s) fora(ram) apagado(s) !!!");
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
					// fecha a conexao//
				dao.fechar();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
}
