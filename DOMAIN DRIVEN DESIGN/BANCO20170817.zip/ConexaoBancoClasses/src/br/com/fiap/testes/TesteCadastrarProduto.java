package br.com.fiap.testes;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Produto;
import br.com.fiap.DAO.ProdutoDAO;

public class TesteCadastrarProduto {

	public static void main(String[] args) {
		
		Produto obj = new Produto();
		
		obj.setNumero(Integer.parseInt(JOptionPane.showInputDialog("Digite o numero")));
		obj.setNome(JOptionPane.showInputDialog("Digite o produto"));
		obj.setCategoria(JOptionPane.showInputDialog("Digite a categoria"));
		
		ProdutoDAO dao = null;
		
		try{
			dao = new ProdutoDAO();
			System.out.println(dao.inserir(obj));
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try{
				System.out.println(dao.fechar());
			} catch (Exception e){
				e.printStackTrace();
			}
		}
	}
}
