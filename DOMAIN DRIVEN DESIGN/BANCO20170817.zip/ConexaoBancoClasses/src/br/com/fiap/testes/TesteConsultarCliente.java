package br.com.fiap.testes;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.DAO.ClienteDAO;

public class TesteConsultarCliente {

	public static void main(String[] args) {
		
		int numero = Integer.parseInt(JOptionPane.showInputDialog("Digite o numero do cliente"));
		
		ClienteDAO dao = null;
		
		try{
			dao = new ClienteDAO();
			Cliente obj = dao.consultar(numero);
			
			System.out.println(obj.getNumero() +" - "+ obj.getNome() +" - "+ obj.getQtEstrelas());
		
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try{
				System.out.println(dao.fechar());
			} catch (Exception e){
				e.printStackTrace();
			}
		}
	}
}
