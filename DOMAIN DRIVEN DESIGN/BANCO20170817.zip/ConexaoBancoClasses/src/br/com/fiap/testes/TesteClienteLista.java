package br.com.fiap.testes;

import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.DAO.ClienteDAO;
import br.com.fiap.beans.Cliente;

public class TesteClienteLista {

	public static void main(String[] args) {

		ClienteDAO dao = null;
		
		try{
			dao = new ClienteDAO();
			
			List<Cliente> lista = dao.getListarNivel(Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de estrelas")));
			
			for (Cliente c : lista){
				System.out.println(c.getNome() +" - "+ c.getNumero());
				System.out.println();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try{
				dao.fechar();
			} catch (Exception e){
				e.printStackTrace();
			}
		}

	}

}
