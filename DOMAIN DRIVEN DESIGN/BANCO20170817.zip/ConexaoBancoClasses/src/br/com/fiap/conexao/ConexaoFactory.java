package br.com.fiap.conexao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexaoFactory {

	
	public Connection conectar() throws Exception{
		return DriverManager.getConnection("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL", "RM78582", "130483");
		//return DriverManager.getConnection("jdbc:oracle:thin:/:@localhost:1521:xe", "RM75761", "narga10");	//CASA
	}
	
}
