package br.com.fiap.beans;

public class Produto {
	private int cd;
	private String nome;
	private String categoria;
	private double valor;
	
	public Produto () {
		super();
	}
	
	public Produto(int cd, String nome, String categoria, double valor) {
		super();
		setCd(cd);
		setNome(nome);
		setCategoria(categoria);
		setValor(valor);
	}

	public int getCd() {
		return cd;
	}
	public void setCd(int cd) {
		this.cd = cd;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	
}


