package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Cliente;
import br.com.fiap.beans.Telefone;
import br.com.fiap.conexao.ConexaoFactory;

public class ClienteDAO {
	private Connection conn;
	
	public ClienteDAO () throws Exception {
		conn = new ConexaoFactory().conectar();
	}
	
	public String fechar() throws Exception {
		conn.close();
		return "Conex�o fechada com sucesso.";
	}
	
	public String gravar(Cliente cliente) throws Exception {
		PreparedStatement pstmt = null; 
		pstmt = conn.prepareStatement("INSERT INTO TB_DDD_CLIENTE "
				+ "(NR_CLIENTE, NM_CLIENTE, QT_ESTRELAS) VALUES (?, ?, ?)");
		pstmt.setInt(1, cliente.getNumero());
		pstmt.setString(2, cliente.getNome());
		pstmt.setInt(3, cliente.getQtdeEstrelas());
		pstmt.execute();
		
		for (Telefone t : cliente.getFones()){
			new TelefoneDAO().gravar(t, cliente.getNumero());
		}
		
		pstmt.close();
		
		return "Cadastrado com sucesso.";
	}
	
	public int excluirNome(String pNome) throws Exception {
		PreparedStatement pstmt = null; 
		pstmt = conn.prepareStatement("DELETE FROM TB_DDD_CLIENTE WHERE NM_CLIENTE = ?");
		pstmt.setString(1, pNome);
		int r = pstmt.executeUpdate();
		pstmt.close();
		return r;
	}
	
	public String elevarNivel(int nrCliente) throws Exception {
		PreparedStatement pstmt = null;
		pstmt = conn.prepareStatement("UPDATE TB_DDD_CLIENTE SET QT_ESTRELAS = QT_ESTRELAS + 1 WHERE NR_CLIENTE = ?");
		pstmt.setInt(1, nrCliente);
		int r = pstmt.executeUpdate();
		pstmt.close();
		return r + " linha(s) foi(ram) alterada(s)!";
	}
	 
	public Cliente getCliente(int numero) throws Exception {		
		Cliente cliente = new Cliente();
		PreparedStatement pstmt = null; 
		ResultSet result = null;
		pstmt = conn.prepareStatement("SELECT NM_CLIENTE, NR_CLIENTE, QT_ESTRELAS"
				+ " FROM TB_DDD_CLIENTE WHERE NR_CLIENTE = ?");
		pstmt.setInt(1, numero);
		result = pstmt.executeQuery();
		if (result.next()) {
			cliente.setNome(result.getString("NM_CLIENTE"));
			cliente.setNumero(result.getInt("NR_CLIENTE"));
			cliente.setQtdeEstrelas(result.getInt("QT_ESTRELAS"));
		}
		result.close();
		pstmt.close();
		return cliente;
	}

	public List<Cliente> getListarNivel (int qtdEstrelas) throws Exception {
		List<Cliente> lista = new ArrayList<>();
		Cliente cliente = new Cliente();
		PreparedStatement pstmt = null; 
		ResultSet result = null;
		pstmt = conn.prepareStatement("SELECT NM_CLIENTE, NR_CLIENTE, QT_ESTRELAS"
				+ " FROM TB_DDD_CLIENTE WHERE QT_ESTRELAS = ?");
		pstmt.setInt(1, qtdEstrelas);
		result = pstmt.executeQuery();
		while (result.next()) {
			cliente = new Cliente();
			cliente.setNome(result.getString("NM_CLIENTE"));
			cliente.setNumero(result.getInt("NR_CLIENTE"));
			cliente.setQtdeEstrelas(result.getInt("QT_ESTRELAS"));
			lista.add(cliente);
		}
		result.close();
		pstmt.close();
		
		return lista;
	}
}

