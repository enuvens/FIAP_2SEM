package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Produto;
import br.com.fiap.conexao.ConexaoFactory;

public class ProdutoDAO {
	private Connection conn;
	
	public ProdutoDAO () throws Exception {
		conn = new ConexaoFactory().conectar();
	}
	public String fechar() throws Exception {
		conn.close();
		return "Conex�o fechada com sucesso.";
	}
	
	public String gravar(Produto produto) throws Exception {
		PreparedStatement pstmt = null; 
		pstmt = conn.prepareStatement("INSERT INTO TB_DDD_PRODUTO "
				+ "(CD_PRODUTO, DS_PRODUTO, NM_CATEGORIA, VL_PRECO) VALUES (?, ?, ?, ?)");
		pstmt.setInt(1, produto.getCd());
		pstmt.setString(2, produto.getNome());
		pstmt.setString(3, produto.getCategoria());
		pstmt.setDouble(4, produto.getValor());
		pstmt.execute();
		pstmt.close();
		return "Cadastrado com sucesso.";
	}
	
	public Produto getProduto (int codigo) throws Exception {
		Produto produto = new Produto();
		PreparedStatement pstmt = null; 
		ResultSet result = null;
		pstmt = conn.prepareStatement("SELECT * FROM TB_DDD_PRODUTO WHERE CD_PRODUTO = ?");
		pstmt.setInt(1, codigo);
		result = pstmt.executeQuery();
		if (result.next()) {
			produto.setCd(result.getInt("CD_PRODUTO"));
			produto.setNome(result.getString("DS_PRODUTO"));
			produto.setCategoria(result.getString("NM_CATEGORIA"));
			produto.setValor(result.getDouble("VL_PRECO"));
		}
		result.close();
		pstmt.close();
		return produto;
	}
	
	public int excluirPorCodigo(int numero) throws Exception {
		PreparedStatement pstmt = null; 
		pstmt = conn.prepareStatement("DELETE FROM TB_DDD_PRODUTO WHERE CD_PRODUTO = ?");
		pstmt.setInt(1, numero);
		int r = pstmt.executeUpdate();
		pstmt.close();
		return r;
	}
	
	public int aumentar(int porcentagem) throws Exception {
		PreparedStatement pstmt = null; 
		pstmt = conn.prepareStatement("UPDATE TB_DDD_PRODUTO SET VL_PRODUTO = VL_PRODUTO + ((?/100) * VL_PRODUTO)");
		pstmt.setInt(1, porcentagem);
		int r = pstmt.executeUpdate();
		pstmt.close();
		return r;
	}
	
	public List<Produto> listarPorCategoria(String categoria) throws Exception {
		List<Produto> lista = new ArrayList<>();
		Produto produto = new Produto();
		PreparedStatement pstmt = null; 
		ResultSet result = null;
		pstmt = conn.prepareStatement("SELECT * FROM TB_DDD_PRODUTO WHERE NM_CATEGORIA = ?");
		pstmt.setString(1, categoria);
		result = pstmt.executeQuery();
		while (result.next()) {
			produto = new Produto();
			produto.setCd(result.getInt("CD_PRODUTO"));
			produto.setNome(result.getString("DS_PRODUTO"));
			produto.setCategoria(result.getString("NM_CATEGORIA"));
			produto.setValor(result.getDouble("VL_PRECO"));
			lista.add(produto);
		}
		result.close();
		pstmt.close();
		
		return lista;
	}

}

