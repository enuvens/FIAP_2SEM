package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import br.com.fiap.beans.Telefone;
import br.com.fiap.conexao.ConexaoFactory;

public class TelefoneDAO {

	private Connection conn;
	
	public TelefoneDAO() throws Exception {
		conn = new ConexaoFactory().conectar();
	}
	
	public String fechar() throws Exception {
		conn.close();
		return "Conex�o fechada com sucesso.";
	}
	
	public String gravar(Telefone telefone, int cliente) throws Exception {
		PreparedStatement pstmt = null; 
		pstmt = conn.prepareStatement("INSERT INTO TB_DDD_TELEFONE "
				+ "(NR_DDD, NR_NUMERO, NM_OPERADORA, NR_CLIENTE) "
				+ "VALUES (?, ?, ?, ?)");
		pstmt.setInt(1, telefone.getDdd());
		pstmt.setString(2, telefone.getNumero());
		pstmt.setString(3, telefone.getOperadora());
		pstmt.setInt(4, cliente);
		pstmt.execute();
		pstmt.close();
		return "Cadastrado com sucesso.";
	}
	
}
