package br.com.fiap.testes;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.bo.ClienteBO;

public class TesteConsultaCliente {

	public static void main(String[] args) {
		try {
			
			Cliente cli = ClienteBO.consultarPorCodigo(Integer.parseInt(JOptionPane.showInputDialog("Digite o numero")));
			
			System.out.println(cli.getNome());
			System.out.println(cli.getQtdeEstrelas());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
