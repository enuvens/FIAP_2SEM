package br.com.fiap.testes;

import br.com.fiap.beans.Produto;
import br.com.fiap.dao.ProdutoDAO;

public class TesteCadastrarProduto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Produto produto = new Produto(1, "TV", "Eletrodom�stico", 3.00);
		ProdutoDAO dao = null;
		try {
			dao = new ProdutoDAO();
			System.out.println(dao.gravar(produto));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				System.out.println(dao.fechar());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		

	}

}
