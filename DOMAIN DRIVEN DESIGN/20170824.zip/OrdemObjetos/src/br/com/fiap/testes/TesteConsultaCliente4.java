package br.com.fiap.testes;

import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.bo.ClienteBO;

public class TesteConsultaCliente4 {

	public static void main(String[] args) {
		try {
			
			List<Cliente> cli = ClienteBO.consultaPorNivel(Integer.parseInt(JOptionPane.showInputDialog("Digite o numero")));
			
			for(Cliente c : cli) {
				System.out.println(c.getNome());
				System.out.println(c.getNumero());
				System.out.println();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
