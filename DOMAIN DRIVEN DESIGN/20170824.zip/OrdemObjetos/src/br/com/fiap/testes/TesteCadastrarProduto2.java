package br.com.fiap.testes;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Produto;
import br.com.fiap.bo.ProdutoBO;

public class TesteCadastrarProduto2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Produto obj = new Produto();
		
		obj.setCd(Integer.parseInt(JOptionPane.showInputDialog("Digite um n�mero")));
		obj.setNome(JOptionPane.showInputDialog("Digite um descri��o"));
		obj.setCategoria(JOptionPane.showInputDialog("Digite a categoria"));
		obj.setValor(Double.parseDouble(JOptionPane.showInputDialog("Digite o valor")));
		
		try {
			System.out.println(ProdutoBO.novoProduto(obj));
		} catch (Exception e) {
			e.printStackTrace();
		} 
		

	}

}
