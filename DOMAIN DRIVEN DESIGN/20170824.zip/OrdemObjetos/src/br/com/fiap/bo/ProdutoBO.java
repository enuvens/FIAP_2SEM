package br.com.fiap.bo;

import br.com.fiap.beans.Produto;
import br.com.fiap.dao.ProdutoDAO;

public class ProdutoBO {

	public static String novoProduto(Produto produto) throws Exception{
		
		if (produto.getValor() < 0) {
			return "Valor inv�lido.";
		}
		
		if (produto.getNome().length() < 5 && produto.getNome().length() > 50){
			return "Descri��o inv�lido.";
		}
		
		if (produto.getCd() < 0 ){
			return "C�digo inv�lido";
		}
		
		if (
				!produto.getCategoria().equals("ELETRONICO") &&
				!produto.getCategoria().equals("ELETROELETRONICO") && 
				!produto.getCategoria().equals("PROMOCAO") &&
				!produto.getCategoria().equals("SUPRIMENTO")
			){
			
			return "Categoria inv�lida";
		}
		
		ProdutoDAO dao = new ProdutoDAO();
		String msg = dao.gravar(produto);
		
		return msg;
		
	}
	
}
