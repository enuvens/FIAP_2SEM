package br.com.fiap.bo;

import br.com.fiap.beans.Cliente;
import br.com.fiap.dao.ClienteDAO;

public class ClienteBO2 {
	public static String novoCliente (String n, int num, int qe) throws Exception {
		
		if (qe < 1 || qe > 5) {
			return "Qtde Estrelas inv�lida.";
		}
		
		if (n.length() > 50){
			return "Nome inv�lido";
		}
		
		if (num<0){
			return "Numero inv�lido";
		}
		
		ClienteDAO dao = new ClienteDAO();
		Cliente objCliente = new Cliente(n, num, qe);
		
		String msg = dao.gravar(objCliente);
		dao.fechar();
		
		return msg;
	}
}