import java.util.Scanner;

public class Exercicio02R {
	public static void main(String args[]) {
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite um numero par");
		int par = scn.nextInt();
		
		System.out.println(calcula(par, 2));
		
		scn.close();
		
	}
	
	public static int calcula(int par, int mais){
		
		int resultado = 0; 
		
		if (mais <= par ){
			resultado = (par + mais + calcula(par, mais+2));
		}

		return resultado;
		
	}
}
