import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * � uma sequ�ncia de n�meros inteiros, come�ando normalmente por 
		 * 0 e 1, na qual, cada termo subsequente corresponde � soma dos 
		 * dois anteriores.
		 * */

		Scanner scn = new Scanner(System.in);

		System.out.println("Digite o final da sequencia Fibonacci");
		int fim = scn.nextInt();
		
		sequencia(fim, 0, 1);
		
		scn.close();
		
	}
	
	public static void sequencia(int fim, int inicio, int inicio2){

		int proximo = 0;
		
		if (inicio2 <= fim){
			if (inicio == 0){
				System.out.println("0");
				System.out.println("1");
				System.out.println("1");
				sequencia(fim, 1, 1);
			} else {
				System.out.println(inicio + inicio2);
				proximo = inicio + inicio2;
				sequencia(fim, inicio2, proximo);
			}
		}
		
	}
	

}
