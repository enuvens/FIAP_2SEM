import java.util.Scanner;

public class Exercicio04 {
	public static void main(String args[]) {
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite um numero impar");
		int par = scn.nextInt();
		
		System.out.println(calcula(par, 1));
		
		scn.close();
		
	}
	
	public static String calcula(int par, int mais){
		
		String resultado = " "; 
		
		if (mais <= par ){
			if (mais%2 != 0){
				resultado += mais + (calcula(par, mais+2));
			}
		}

		return resultado;
		
	}
}
