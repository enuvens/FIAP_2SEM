import java.util.Scanner;

public class Extra02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x = 0;
		int y = 0;
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite um valor");
		x = scn.nextInt();
		
		System.out.println("Digite outro valor");
		y = scn.nextInt();

		System.out.println(calcula(x, y));
		
		scn.close();
	}
	
	public static int calcula(int x, int y){
//		System.out.println(Math.pow(x, y));
		int resultado = 1;
		
		for (int i = 1; i <= y; i++ ){
			resultado *= x ; 
		}
		
		return resultado;
	}

}
