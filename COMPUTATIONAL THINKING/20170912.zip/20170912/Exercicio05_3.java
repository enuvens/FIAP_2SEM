

public class Exercicio05_3 {
	
	public static void main(String args[]) {
		int fim = 50;
		calcula(fim);
	}
	
	public static void calcula(int par){

		for (int i = 1; i <= par; i++){
			System.out.println(i + " | ");
		}
	}
}
