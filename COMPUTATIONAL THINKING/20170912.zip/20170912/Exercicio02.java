import java.util.Scanner;

public class Exercicio02 {

	public static void main(String args[]) {
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite um numero par");
		int par = scn.nextInt();
		
		System.out.println(calcula(par));
		
		scn.close();
		
	}
	
	public static int calcula(int par){
		
		int resultado = 0; 
		
		for (int i = 0; i <= par; i++){
			
			if (i > 0){
				if (i%2 == 0){
					resultado += i + par;
					System.out.println(resultado +"+"+ i +"+"+ par);
				}
			}
		}
		
		return resultado;
	}


}
