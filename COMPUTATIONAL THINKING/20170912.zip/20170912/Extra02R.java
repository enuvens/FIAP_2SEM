import java.util.Scanner;

public class Extra02R {

	public static void main(String[] args) {

		int x = 0;
		int y = 0;
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite um valor");
		x = scn.nextInt();
		
		System.out.println("Digite outro valor");
		y = scn.nextInt();

		System.out.println(calcula(x, y));
		
		scn.close();
		
	}
	
	public static int calcula(int x, int y){

		int aux = 0;
		
		if (y == 0) {
			return 1;
		} else {
			aux = calcula(x, y/2);
			if (y%2 == 0) {
				return aux * aux;
			} else {
				return aux * aux * x;
			}
		}
		
	}

}
