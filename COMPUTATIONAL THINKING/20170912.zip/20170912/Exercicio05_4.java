import java.util.Scanner;

public class Exercicio05_4 {
	public static void main(String args[]) {
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite um numero impar");
		int par = scn.nextInt();
		
		calcula(par);
		
		scn.close();
		
	}
	
	public static void calcula(int par){
		
		
		for (int i = 1; i <= par; i++){
			if (i%2 != 0){
				System.out.println(i + " | ");
			}
		}
		
	}
}
