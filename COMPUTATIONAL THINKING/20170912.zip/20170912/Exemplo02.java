import java.util.Scanner;

public class Exemplo02 {
	public static void main(String args[]) {
		long x;
		long r;
		Scanner s = new Scanner(System.in);
		System.out.print("Entre um valor inteiro (de 0 ate 25):");
		x = s.nextByte();
		System.out.println();
		r = fatorial(x);
		System.out.println();
		System.out.println("Fatorial de " + x + "=" + r);
		s.close();
	}

	public static long fatorial(long n) {
		if (n == 0) //if == 1 n�o precisa chamar o 0
			return (1);
		else
			return (fatorial(n - 1) * n);
	}
}
