

public class Exercicio03 {
	
	public static void main(String args[]) {
		int inicio = 1;
		calcula(inicio);
	}
	
	public static void calcula(int par){

		if (par <= 50){
			if (par == 1){
				System.out.println("1 | ");
				calcula(par+1);
			} else {
				System.out.println(par +" | ");
				calcula(par+1);
			}
		}
	}
}
