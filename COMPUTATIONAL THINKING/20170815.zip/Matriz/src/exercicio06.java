
public class exercicio06 {

	public static void main(String[] args) {
	
		int codigos[] = new int[5];
		String nomes[] = new String[5];
		String loja[] = new String[6];
		double preco[][] = new double[5][6];
		
		String mensagem = "";
		
		for (int i = 0; i < 5; i++){
			codigos[i] = i;
			nomes[i] = "Produto "+ (i+1);
			
			System.out.println(codigos[i] +" - "+ nomes[i]);
		}
		
		for (int j = 0; j < 6; j++){
			loja[j] = "Loja "+ (j+1);
			
			System.out.println(loja[j]);
		}
		
		for (int l = 0; l < 5; l++){
			for (int c = 0; c < 6; c++){
				preco[l][c] = Math.round(Math.random() * 100);
				
				if (c == 0){
					mensagem += "Pre�o: ";
				}
				
				mensagem += preco[l][c] +" | ";
				
				if (c == 5){
					mensagem += "\n";
				}
			}
		}
		
		
		System.out.println("PROMO��ES\n");
		
		double menor1 = 0;
		double menor2 = 0;
		double menor3 = 0;
		double menor4 = 0;
		double menor5 = 0;
		
		int pos1 = 0;
		int pos2 = 0;
		int pos3 = 0;
		int pos4 = 0;
		int pos5 = 0;
		
		for (int l2 = 0; l2 < 5; l2++){
			for (int c2 = 0; c2 < 6; c2++){

				//Produto 1
				if (l2 == 0){
					if (menor1 == 0 ){
						menor1 = preco[l2][c2];
						pos1 = 0;
					} else if (menor1 > preco[l2][c2]){
						menor1 = preco[l2][c2];
						pos1 = l2;
					}
				}
				
				//Produto 2
				if (l2 == 1){
					if (menor2 == 0 ){
						menor2 = preco[l2][c2];
						pos2 = 0;
					} else if (menor2 > preco[l2][c2]){
						menor2 = preco[l2][c2];
						pos2 = l2;
					}
				}
				
				//Produto 1
				if (l2 == 2){
					if (menor3 == 0 ){
						menor3 = preco[l2][c2];
						pos3 = 0;
					} else if (menor3 > preco[l2][c2]){
						menor3 = preco[l2][c2];
						pos3 = l2;
					}
				}
				
				//Produto 1
				if (l2 == 3){
					if (menor4 == 0 ){
						menor4 = preco[l2][c2];
						pos4 = 0;
					} else if (menor4 > preco[l2][c2]){
						menor4 = preco[l2][c2];
						pos4 = l2;
					}
				}
				
				//Produto 1
				if (l2 == 4){
					if (menor5 == 0 ){
						menor5 = preco[l2][c2];
						pos5 = 0;
					} else if (menor5 > preco[l2][c2]){
						menor5 = preco[l2][c2];
						pos5 = l2;
					}
				}
					
			}
		}
		
		System.out.println(mensagem +"\n\n");
		
		System.out.println("O Produto 1 foi encontrado na Loja "+ (pos1+1) +" por R$ "+ menor1 );
		System.out.println("O Produto 2 foi encontrado na Loja "+ (pos2+1) +" por R$ "+ menor2 );
		System.out.println("O Produto 3 foi encontrado na Loja "+ (pos3+1) +" por R$ "+ menor3 );
		System.out.println("O Produto 4 foi encontrado na Loja "+ (pos4+1) +" por R$ "+ menor4 );
		System.out.println("O Produto 5 foi encontrado na Loja "+ (pos5+1) +" por R$ "+ menor5 );
		
	}

}
