import java.util.*;
import java.text.*;

public class Vetor{

	public static void main(String[] args){
		DecimalFormat df = new DecimalFormat("0.00"); 
		Scanner entrada = new Scanner(System.in);
		boolean resp=false;
		int numeros, resultado=0, x=0;
		int vetor[] = new int [10];
		int repetidos[] = new int [10];
		int matriz [][] = new int [10][2];
		System.out.println ("\n ---->>> Cadastre 10 numeros <<<---- ");
		for(int i=0; i<10; i++)
		{
			System.out.print ("Numero " + (i+1) + ": ");	
			numeros = entrada.nextInt();
			vetor[i] = numeros;
		}

		System.out.println(" ");

		// frequencia dos numeros
		System.out.print("\n Frequencia dos numeros \n");
		int cont=1;
		int num=0;
		for(int i=0; i<vetor.length; i++){
			cont=0;
			for(int j=0; j<vetor.length; j++)
			{
				if (vetor[i] == vetor[j])
					cont++;
				num = vetor[i];
			}
			System.out.println(" repeticoes numero " + num + ": " + cont + " vezes");	
		}
	}
}