import java.util.Scanner;

public class JogoVelha {

	public static void main(String[] args) {

		int jogo[][] = new int[3][3];
		int ganhou = 0;
		
		int player = 0;
		int linha = 0;
		int coluna = 0;
		
		int numeros = 0;
		
		String mensagem = "";
		
		System.out.println("==============================================");
		System.out.println("JOGO DA VELHA");
		System.out.println("==============================================");
		
		Scanner scn = new Scanner(System.in); 
		
		for (int l = 0; l < 3; l++){
			for (int c = 0; c < 3; c++){
				jogo[l][c] = 0;
			}
		}
		
		do {

				if (player == 1){
					player = 2;
				} else{
					player = 1;
				}
			
				System.out.println("Player "+ player +": Digite a LINHA que voc� quer preencher");
				linha = scn.nextInt();
				
				
				System.out.println("Player "+ player +": Digite a COLUNA que voc� quer preencher");
				coluna = scn.nextInt();
		
				if (linha > 2 || coluna > 2){
					System.out.println("Numero invalido, digite novamente");
					if (player == 2){
						player = 1;
					} else {
						player = 2;
					}
				} else {
				
					if (jogo[linha][coluna] != 0 ){
						System.out.println("A Linha x Coluna j� est� preenchida");
						if (player == 2){
							player = 1;
						} else {
							player = 2;
						}
					} else {
						jogo[linha][coluna] = player;
						numeros++;
					}
					
					for (int l = 0; l < 3; l++){
						if (jogo[l][0] == 1 && jogo[l][1] == 1 && jogo[l][2] == 1){
							ganhou = 1;
							System.out.println("O player 1 venceu");
						}
						if (jogo[l][0] == 2 && jogo[l][1] == 2 && jogo[l][2] == 2){
							ganhou = 1;
							System.out.println("O player 2 venceu");
						}	
					}
					
					if (jogo[0][0] == 1 && jogo[1][1] == 1 && jogo[2][2] == 1){
						ganhou = 1;
						System.out.println("O player 1 venceu");
					}
					
					if (jogo[0][0] == 2 && jogo[1][1] == 2 && jogo[2][2] == 2){
						ganhou = 1;
						System.out.println("O player 2 venceu");
					}
					
					if (jogo[0][2] == 1 && jogo[1][1] == 1 && jogo[2][0] == 1){
						ganhou = 1;
						System.out.println("O player 1 venceu");
					}
					
					if (jogo[0][2] == 2 && jogo[1][1] == 2 && jogo[2][0] == 2){
						ganhou = 1;
						System.out.println("O player 2 venceu");
					}
					
					
					
				}

				if (numeros == 9){
					System.out.println("O jogo terminou empatado");
					ganhou = 1;
				}
				
				if (ganhou == 1){
					for (int l = 0; l < 3; l++){
						for (int c = 0; c < 3; c++){
							mensagem += jogo[l][c] +" | ";
							
							if (c == 2){
								mensagem += "\n";
							}
						}
						
						
					}
					System.out.println(mensagem);
				}
			
		} while (ganhou != 1);
		
		scn.close();

	}

}
