import java.util.Scanner;

public class exercicio02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int matrizM[][] = new int [4][4];
		int matrizR[][] = new int [4][4];
		int numero = 0;
		int maior = 0;
		String mensagem = "";
		
		Scanner scn = new Scanner(System.in);
		
		mensagem += "------------MATRIZ M ------------\n";
		for (int l = 0; l < 4; l++){
			for (int c = 0; c < 4; c++){
				
				System.out.println("Digite um numero para a linha "+ (l+1) +" e coluna "+ (c+1));
				numero = scn.nextInt();
				matrizM[l][c] = numero;
				
				if (l == 0 && c == 0){
					maior = numero;
				} else {
					if (numero > maior){
						maior = numero;
					}
				}
				
				mensagem += matrizM[l][c] + " | ";
				if (c == 3){
					mensagem += "\n";
				}
			}
		}
		
		mensagem += "------------MATRIZ R ------------\n";
		
		for (int l = 0; l < 4; l++){
			for (int c = 0; c < 4; c++){
				
				matrizR[l][c] = (matrizM[l][c] * maior);
				
				mensagem += matrizR[l][c] + " | ";
				if (c == 3){
					mensagem += "\n";
				}
			}
		}
		
		System.out.println(mensagem);
		
		scn.close();

	}

}
