import java.util.Scanner;

public class exercicio04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int matrizM[][] = new int [5][5];
		int matrizN[][] = new int [5][5];
		int numero = 0;
		String mensagem = "";
		
		Scanner scn = new Scanner(System.in);
		
		for (int l = 0; l < 5; l++){
			for (int c = 0; c < 5; c++){
				
				System.out.println("Digite um numero para a linha "+ (l+1) +" e coluna "+ (c+1));
				numero = scn.nextInt();
				matrizM[l][c] = numero;
				
				
				
			}
		}
		
	int cont=1;
	int num=0;
	for(int i=0; i<matrizM.length; i++){
		cont=0;
		for(int j=0; j<matrizM.length; j++){
			for (int p = 0; p < 5; p++){
				if (matrizM[i][p] == matrizM[j][p])
					cont++;
				num = matrizM[i][p];
			}
		}
		System.out.println(" repeticoes numero " + num + ": " + cont + " vezes");
	}
		
	scn.close();

	}

}
