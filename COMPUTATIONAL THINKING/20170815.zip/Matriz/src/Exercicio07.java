import java.util.Scanner;

public class Exercicio07 {

	public static void main(String[] args) {

		int matriz[][] = new int [7][7];
		int soma = 0;
		
		String resultado = "";
		
		Scanner scn = new Scanner(System.in);
		
		for (int l = 0; l < 7; l++){
			for (int c = 0; c < 7; c++){
				System.out.println("Digite um numero para a linha "+ (l+1) +" e coluna "+ (c+1));
				matriz[l][c] = scn.nextInt();
				
				resultado += matriz[l][c] +" ";
				
				if ((l+c) >= 7){
					soma = soma + matriz[l][c];
					System.out.println("somou");
				}
				
				if (c == 6){
					resultado += "\n";
				}
			}
		}
		
		System.out.println(resultado);
		
		System.out.println(soma);
		scn.close();

	}

}
