import java.util.Scanner;

public class Exercicio04 {

	public static void main(String[] args) {

		float nota1, nota2, nota3;
		String opcao = "";
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite a nota 1 do aluno");
		nota1 = scn.nextFloat();
		
		System.out.println("Digite a nota 2 do aluno");
		nota2 = scn.nextFloat();
		
		System.out.println("Digite a nota 3 do aluno");
		nota3 = scn.nextFloat();
		
		System.out.println("Digite a op��o desejada");
		opcao = scn.next();
		
		calcula(nota1, nota2, nota3, opcao);
	}
	
	public static void calcula(float nota1, float nota2, float nota3, String opcao){
	
		// Se Op��o = A M�dia Aritmetica
		// Se Op��o = P M�dia Ponderada com pesos 5, 3 e 2
		
		
		if (opcao.equals("A")){
			System.out.println("A m�dia aritmetica � "+ (nota1 + nota2 + nota3)/3);
		} else {
			float n1 = nota1 * 5;
			float n2 = nota2 * 3;
			float n3 = nota3 * 2;
			
			float soma = ((n1 + n2 + n3) / 10);
			
			System.out.println("A m�dia ponderada � "+ soma);
		}
		
		
	}
}
