import java.util.Scanner;

public class Tempo {

	public static void main(String[] args) {

		int segundos = 0;
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Entre com a quantidade de segundos");
		segundos = scn.nextInt();
		
		calcula(segundos);
		
		scn.close();
	}
	
	public static void calcula(int tempo){
		
		int segundos = tempo % 60;
	    tempo = tempo / 60;
	    
	    int minutos = tempo % 60;
	    tempo = tempo / 60;
	    
	    int horas = tempo % 24;
	    
	    if (horas > 0){
	    	System.out.println(horas + " hora(s)");
	    }
	    
	    if (minutos > 0){
	    	System.out.println(minutos + " minuto(s)");
	    }
	    
	    System.out.println(segundos +" segundos"); 
		
		
	}
}
