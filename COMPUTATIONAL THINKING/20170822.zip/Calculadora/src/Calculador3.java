import java.util.Scanner;

public class Calculador3 {

	public static void main(String[] args) {
		
		int num1, num2;
		String operacao;
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite o numero 1");
		num1 = scn.nextInt();
		
		System.out.println("Digite a opera��o desejada:");
		System.out.println("[+] para somar\n"
				+ "[-] para subtrair\n"
				+ "[/] para dividir\n"
				+ "[*] para multiplicar\n");
		operacao = scn.next();
		
		System.out.println("Digite o numero 2");
		num2 = scn.nextInt();
		
		System.out.println(calcular(num1, num2, operacao));
		
		scn.close();

	}
	
	public static String calcular(int num1, int num2, String operacao){
	
		String msg = "";
		
		msg = "Resultado: ";
		
		switch(operacao){
			case "+":
				msg += num1 + num2;
				break;
			case "-":
				msg += num1 - num2;
				break;
			case "/":
				msg += num1 / num2;
				break;
			case "*":
				msg += num1 * num2;
				break;
			default:
				msg += "Opera��o n�o reconhecida";
				break;
		}
		
		return msg;
	}
	
}
