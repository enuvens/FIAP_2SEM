import java.util.Scanner;

public class Calculadora {

	public static void main(String[] args) {
		
		String operacao = "";
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite a opera��o desejada:");
		System.out.println("[+] para somar\n"
				+ "[-] para subtrair\n"
				+ "[/] para dividir\n"
				+ "[*] para multiplicar\n");
		operacao = scn.next();
		
		switch(operacao){
			case "+":
				somar();
				break;
			case "-":
				subtrair();
				break;
			case "/":
				dividir();
				break;
			case "*":
				multiplicar();
				break;
			default:
				System.out.println("Opera��o n�o reconhecida");
				break;
		}
		
		scn.close();

	}
	
	public static void somar(){
		int num1, num2, soma;
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite o numero que deseja somar");
		num1 = scn.nextInt();
		
		System.out.println("Digite o segundo numero que deseja somar");
		num2 = scn.nextInt();
		
		soma = num1 + num2;
		
		System.out.println("Resultado: "+ soma);
		
		scn.close();
	}
	
	public static void subtrair(){
		int num1, num2, subtrair;
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite o numero que deseja subtrair");
		num1 = scn.nextInt();
		
		System.out.println("Digite o segundo numero que deseja subtrair");
		num2 = scn.nextInt();
		
		subtrair = num1 - num2;
		
		System.out.println("Resultado: "+ subtrair);
		
		scn.close();
	}
	
	public static void dividir(){
		int num1, num2, dividir;
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite o numero que deseja dividir");
		num1 = scn.nextInt();
		
		System.out.println("Digite o segundo numero que deseja dividir");
		num2 = scn.nextInt();
		
		dividir = num1 / num2;
		
		System.out.println("Resultado: "+ dividir);
		
		scn.close();
	}
	
	public static void multiplicar(){
		int num1, num2, multiplicar;
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite o numero que deseja multiplicar");
		num1 = scn.nextInt();
		
		System.out.println("Digite o segundo numero que deseja multiplicar");
		num2 = scn.nextInt();
		
		multiplicar = num1 * num2;
		
		System.out.println("Resultado: "+ multiplicar);
		
		scn.close();
	}

}
