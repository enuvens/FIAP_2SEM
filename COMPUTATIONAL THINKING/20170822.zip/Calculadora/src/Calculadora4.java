import java.util.Scanner;

public class Calculadora4 {

	public static void main(String[] args) {

		int num1, num2, resultado = 0, x = 0;
		String operacao;

		Scanner scn = new Scanner(System.in);

		do {

			if (x == 0) {
				System.out.println("Digite o numero 1");
				num1 = scn.nextInt();
			} else {
				num1 = resultado;
			}

			System.out.println("Digite o numero 2");
			num2 = scn.nextInt();

			System.out.println("Digite a opera��o desejada:");
			System.out.println(
					"[+] para somar | " + 
					"[-] para subtrair\n" + 
					"[/] para dividir | " + 
					"[*] para multiplicar\n[S] para sair");

			operacao = scn.next();
			
			if (!operacao.equals("S")){
				resultado = calcular(num1, num2, operacao);
			
				System.out.println("Resultado: "+ resultado);
			}
			x++;

		} while (!operacao.equals("S"));

		scn.close();
	}

	public static int calcular(int num1, int num2, String operacao) {

		int retorno = num1;

		switch (operacao) {
		case "+":
			retorno = num1 + num2;
			break;
		case "-":
			retorno = num1 - num2;
			break;
		case "/":
			retorno = num1 / num2;
			break;
		case "*":
			retorno = num1 * num2;
			break;
		}

		return retorno;
	}

}
