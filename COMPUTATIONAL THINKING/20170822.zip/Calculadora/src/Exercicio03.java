import java.util.Scanner;

public class Exercicio03 {

	public static void main(String[] args) {

		float preco1, preco2;
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite o valor antigo do produto");
		preco1 = scn.nextFloat();
		
		System.out.println("Digite o valor novo do produto");
		preco2 = scn.nextFloat();
		
		calcula(preco1, preco2);
		
	}
	
	public static void calcula(float preco1, float preco2){
		
		float percentual = ((preco1 - preco2) / preco1) * 100;
		
		if (preco1 < preco2){
			System.out.println("O valor novo � "+ percentual * -1 +"% mais caro que o antigo");
		} else {
			System.out.println("O valor novo � "+ percentual +"% mais barato que o antigo");
		}
	}

}
