import java.util.Scanner;

public class Calculadora2 {

	public static void main(String[] args) {
		
		int num1, num2;
		String operacao;
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite o numero 1");
		num1 = scn.nextInt();
		
		System.out.println("Digite a opera��o desejada:");
		System.out.println("[+] para somar\n"
				+ "[-] para subtrair\n"
				+ "[/] para dividir\n"
				+ "[*] para multiplicar\n");
		operacao = scn.next();
		
		System.out.println("Digite o numero 2");
		num2 = scn.nextInt();
		
		calcular(num1, num2, operacao);
		
		scn.close();

	}
	
	public static void calcular(int num1, int num2, String operacao){
	
		System.out.println("Resultado: ");
		
		switch(operacao){
			case "+":
				System.out.println(num1 + num2);
				break;
			case "-":
				System.out.println(num1 - num2);
				break;
			case "/":
				System.out.println(num1 / num2);
				break;
			case "*":
				System.out.println(num1 * num2);
				break;
			default:
				System.out.println("Opera��o n�o reconhecida");
				break;
		}
		
	}
	
}
