import java.util.Scanner;

public class Media {

	public static void main(String[] args) {

		float num1, num2;
		
		Scanner scn = new Scanner(System.in);
		
		System.out.println("Digite o numero 1");
		num1 = scn.nextInt();

		
		System.out.println("Digite o numero 2");
		num2 = scn.nextInt();
		
		soma(num1, num2);
		
		scn.close();
	}
	
	public static void soma(float num1, float num2){
		
		System.out.println(num1 + num2);
	}

}
